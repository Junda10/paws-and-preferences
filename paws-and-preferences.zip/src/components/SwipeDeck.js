console.log("Loading SwipeDeck.js");
import TinderCard from 'react-tinder-card';
import { fetchCats } from '../services/cataas';
import '../App.css'; // Make sure this is correct!

export default function SwipeDeck({ onComplete }) {
  const [cats, setCats] = useState([]);
  const [liked, setLiked] = useState([]);

  useEffect(() => {
    fetchCats(15)
      .then((urls) => setCats(urls))
      .catch((err) => console.error('cat fetch error:', err));
  }, []);

  if (cats.length === 0) {
    return <div style={{ padding: '2rem', textAlign: 'center' }}>Loading kittens…</div>;
  }

  const swiped = (dir, url) => {
    if (dir === 'right') setLiked((prev) => [...prev, url]);
    if (liked.length + 1 === cats.length) {
      onComplete(dir === 'right' ? [...liked, url] : liked);
    }
  };

  return (
    <div className="deck-container">
      {cats.map((url) => (
        <TinderCard key={url} onSwipe={(dir) => swiped(dir, url)} preventSwipe={['up', 'down']}>
          <div className="card" style={{ backgroundImage: `url(${url})` }} />
        </TinderCard>
      ))}
    </div>
  );
}
