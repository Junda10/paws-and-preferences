import axios from 'axios';

// Fetch one random cat JSON, return the full image URL
export const fetchRandomCat = async () => {
  // Ask for JSON explicitly
  const { data } = await axios.get('/cat', {
    params: { json: true },
    headers: { Accept: 'application/json' }
  });
  return `https://cataas.com${data.url}`;
};

// Fetch `count` cats in parallel
export const fetchCats = (count = 10) =>
  Promise.all(
    Array.from({ length: count }).map(() => fetchRandomCat())
  );
